// Простое объявление типов для pdfkit
declare module 'pdfkit' {
  class PDFDocument {
    constructor(options?: any);
    pipe(stream: any): any;
    text(text: string, options?: any): this;
    fontSize(size: number): this;
    moveDown(lines?: number): this;
    addPage(): this;
    end(): void;
  }
  
  export default PDFDocument;
}