/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Отключаем transpilePackages чтобы решить проблему с TypeScript
  transpilePackages: ['class-variance-authority', 'clsx', 'tailwind-merge', 'lucide-react'],
  // Обновленная конфигурация для корректной работы серверных модулей
  serverExternalPackages: ['fs', 'path', 'pdfkit'],

  // Обработка TypeScript
  experimental: {
    externalDir: true,
  },
};

module.exports = nextConfig;
